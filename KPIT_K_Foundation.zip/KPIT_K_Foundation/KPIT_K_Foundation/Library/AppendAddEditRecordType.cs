
namespace KPIT_K_Foundation
{
  internal enum AppendAddEditRecordType
  {
    AddEdit,
    GridView,
  }
}
