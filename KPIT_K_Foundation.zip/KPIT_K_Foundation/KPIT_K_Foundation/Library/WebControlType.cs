
namespace KPIT_K_Foundation
{
  internal enum WebControlType
  {
    TextBox,
    TextBoxDate,
    TextArea,
    CheckBox,
  }
}
