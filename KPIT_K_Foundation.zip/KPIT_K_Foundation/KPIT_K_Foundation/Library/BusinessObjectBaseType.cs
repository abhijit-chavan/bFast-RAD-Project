
namespace KPIT_K_Foundation
{
  internal enum BusinessObjectBaseType
  {
    BusinessObjectBase,
    MethodsForApiControllerBase,
  }
}
