
namespace KPIT_K_Foundation
{
  internal enum ControllerBaseType
  {
    ControllerBase,
    ApiControllerBase,
  }
}
