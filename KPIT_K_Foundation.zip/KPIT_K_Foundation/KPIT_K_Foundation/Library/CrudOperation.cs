
namespace KPIT_K_Foundation
{
  internal enum CrudOperation
  {
    Select,
    Insert,
    Update,
    Delete,
    None,
  }
}
