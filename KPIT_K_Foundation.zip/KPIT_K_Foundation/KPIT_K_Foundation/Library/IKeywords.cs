
namespace KPIT_K_Foundation
{
  public interface IKeywords
  {
    bool IsThisVariableAKeyword(string variable);
  }
}
