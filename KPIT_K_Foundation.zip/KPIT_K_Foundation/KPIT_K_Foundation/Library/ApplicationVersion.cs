
namespace KPIT_K_Foundation
{
  internal enum ApplicationVersion
  {
    Express,
    ProfessionalPlus,
  }
}
