
namespace KPIT_K_Foundation
{
  internal enum RelatedTablePart
  {
    BusinessObjectBaseWritePrivateMembers,
    BusinessObjectBaseWriteProperties,
    DataLayerBaseWriteSelectAllRelatedMethods,
    DataLayerBaseWriteSelectByPrimaryKeyMethod,
    DataLayerBaseWriteSelectSharedMethod,
    CodeExampleSelects,
  }
}
