
namespace KPIT_K_Foundation
{
  internal enum Language
  {
    CSharp,
    VB,
  }
}
