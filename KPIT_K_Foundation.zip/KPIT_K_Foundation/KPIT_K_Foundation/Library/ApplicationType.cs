
namespace KPIT_K_Foundation
{
  internal enum ApplicationType
  {
    ASPNET,
    ASPNET45,
    ASPCORE20MVC,
    ASPCORE20RAZOR,
    ASPNETMVC,
    ASPNETMVC5,
    WINFORMS,
  }
}
