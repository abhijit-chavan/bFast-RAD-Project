
namespace KPIT_K_Foundation
{
  internal enum GridViewType
  {
    Redirect,
    AddEdit,
    ReadOnly,
    MoreInfoOnly,
    Totals,
    FilterBy,
    Grouping,
    NotAGridView,
    Inline,
    Search,
  }
}
