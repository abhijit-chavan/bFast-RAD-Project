
namespace KPIT_K_Foundation
{
  internal enum AppendAddEditRecordContentType
  {
    None,
    AddEditGridView,
    AddEditPartialView,
    Details,
    Unbound,
  }
}
