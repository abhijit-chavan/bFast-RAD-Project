
namespace KPIT_K_Foundation
{
  internal enum DatabaseObjectToGenerateFrom
  {
    Tables,
    Views,
  }
}
