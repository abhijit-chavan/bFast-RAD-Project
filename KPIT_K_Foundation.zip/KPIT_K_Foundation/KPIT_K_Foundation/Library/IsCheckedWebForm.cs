
namespace KPIT_K_Foundation
{
  internal class IsCheckedWebForm
  {
    internal bool GridViewRedirect { get; set; }

    internal bool GridViewAddEdit { get; set; }

    internal bool GridViewReadOnly { get; set; }

    internal bool GridViewMoreInfo { get; set; }

    internal bool GridViewFilterBy { get; set; }

    internal bool GridViewTotals { get; set; }

    internal bool GridViewGrouping { get; set; }

    internal bool AddEdit { get; set; }

    internal bool RecordDetails { get; set; }

    internal bool Unbound { get; set; }

    internal bool GridViewInline { get; set; }

    internal bool GridViewSearch { get; set; }
  }
}
