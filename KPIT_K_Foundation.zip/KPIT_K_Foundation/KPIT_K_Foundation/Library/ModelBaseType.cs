
namespace KPIT_K_Foundation
{
  internal enum ModelBaseType
  {
    ModelBase,
    FieldsBase,
  }
}
