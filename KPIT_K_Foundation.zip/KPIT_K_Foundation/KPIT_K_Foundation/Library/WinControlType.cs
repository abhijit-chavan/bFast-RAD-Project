
namespace KPIT_K_Foundation
{
  internal enum WinControlType
  {
    TextBox,
    MaskedTextBoxNumeric,
    MaskedTextBoxWithDecimal,
    ComboBox,
    DateTimePicker,
    CheckBox,
  }
}
