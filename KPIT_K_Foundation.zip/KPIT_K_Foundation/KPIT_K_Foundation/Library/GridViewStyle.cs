
namespace KPIT_K_Foundation
{
  internal enum GridViewStyle
  {
    Slate,
    Colorful,
    Classic,
    Simple,
    Professional,
    Autumn,
    Oceanica,
    BrownSugar,
    SandAndSky,
    RainyDay,
    SnowPine,
    LilacsInMist,
    BlackAndBlue,
    CloverField,
    AppleOrchard,
    Mocha,
  }
}
