using System.Collections.Generic;
using System.Text;

namespace KPIT_K_Foundation
{
    internal class Tables : List<Table>
    {
        internal Tables()
        {
        }
    }
}
