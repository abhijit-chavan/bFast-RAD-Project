
namespace KPIT_K_Foundation
{
  public enum StartUpType
  {
    WebApp,
    WebAPI,
  }
}
