
namespace KPIT_K_Foundation
{
  internal enum GeneratedSqlType
  {
    EFCore,
    StoredProcedures,
    AdHocSQL,
  }
}
