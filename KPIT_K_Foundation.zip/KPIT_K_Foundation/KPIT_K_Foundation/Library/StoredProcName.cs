
namespace KPIT_K_Foundation
{
  internal enum StoredProcName
  {
    SelectByPrimaryKey,
    SelectAll,
    SelectAllBy,
    SelectSkipAndTake,
    SelectSkipAndTakeBy,
    SelectSkipAndTakeWhereDynamic,
    SelectTotals,
    SelectAllWhereDynamic,
    GetRecordCount,
    GetRecordCountBy,
    GetRecordCountWhereDynamic,
    Insert,
    Update,
    Delete,
    SelectDropDownListData,
  }
}
