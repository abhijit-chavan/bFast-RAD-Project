
namespace KPIT_K_Foundation
{
  internal enum AddOrUpdateType
  {
    Add,
    Update,
    Unbound,
  }
}
