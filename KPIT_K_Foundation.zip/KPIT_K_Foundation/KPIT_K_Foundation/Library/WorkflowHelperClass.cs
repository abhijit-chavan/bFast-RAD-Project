﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static KPIT_K_Foundation.AutoCodeGenerator;

namespace KPIT_K_Foundation.Library
{
    public class WorkflowHelperClass
    {
        private string _stWorkflowName;
        //private int _inNumberOfWorkflow;
        private int _inNumberOfSteps;
        //private int _inEscalationTime;
        private string _table;
        private string _createdBy;
        private string _modifiedBy;
        private DateTime _createdOn;
        private DateTime _modifiedOn;
        private string _connectionString;
        private bool _status;
        private List<ApprovalLevel> gridViewList;


        public WorkflowHelperClass()
        {

        }
        public WorkflowHelperClass(string table, string stWorkflowName, int inNumberOfSteps, string createdBy, string modifiedBy, DateTime createdOn, DateTime modifiedOn, string connectionString, bool status, List<ApprovalLevel> dataGridView)
        {
            this._table = table;
            this._stWorkflowName = stWorkflowName;
            //this._inNumberOfWorkflow = inNumberOfWorkflows;
            this._inNumberOfSteps = inNumberOfSteps;
            //this._inEscalationTime = inEscalationTime;
            this._createdBy = createdBy;
            this._createdOn = createdOn;
            this._modifiedBy = modifiedBy;
            this._modifiedOn = modifiedOn;
            this._connectionString = connectionString;
            this._status = status;
            this.gridViewList = dataGridView;
            this.CreateTable();
        }

        public void CreateTable()
        {
            Dbase dbase = new Dbase();
            SqlConnection connection = new SqlConnection(_connectionString);
            connection.Open();
            string query =
            @" IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES 
              WHERE TABLE_NAME='WorkflowMaster') 

              BEGIN

              CREATE TABLE [dbo].[WorkflowMaster](
              [WorkflowId] [int] PRIMARY KEY IDENTITY(1, 1),
              [WorkflowName] [nvarchar](50) NOT NULL,
              [LevelOfApprovals] [int] ,
              [CreatedBy] [varchar](50) NULL,
              [CreatedOn] [DateTime] NOT NULL,
              [Updatedby] [nvarchar](50) null,
              [Updatedon] [datetime] not null);

              END  ";
            query = query + @" IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES 
              WHERE TABLE_NAME='WorkflowStepsMaster') 

              BEGIN

              CREATE TABLE [dbo].[WorkflowStepsMaster](
              [StepId] int PRIMARY KEY IDENTITY (1, 1),
              [WorKflowId] int FOREIGN KEY REFERENCES WorkflowMaster(WorkflowId),
              [ApprovalLevel] [nvarchar](50),
              [Description] [nvarchar](50),
              [AutoApprove] [nvarchar](50),
              [WaitTime] [int],
              [CreatedBy] [nvarchar](50),
              [CreatedOn] [DateTime] NOT NULL,
              [UpdatedBy] [nvarchar](50) null,
              [UpdatedOn] [DateTime] NOT NULL);
              
              END ";
            query = query + @" IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES 
              WHERE TABLE_NAME='UserMaster') 

              BEGIN
              CREATE TABLE [dbo].[UserMaster](
              [UserId] int PRIMARY KEY IDENTITY (1, 1),
              [UserName] nvarchar(50),
              [Password] nvarchar(50),
              [Email] nvarchar(50),
              [CreatedOn] DateTime NOT NULL,
              [CreatedBy] nvarchar(50) not null,
              [ModifiedOn] DateTime  NULL,
              [ModifiedBy] nvarchar(50) null); 
              INSERT INTO UserMaster(UserName,[Password],Email,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy )
              Values('Sristi Annu','1234','sristia@birlasoft.com',getdate(),'System',null,null),
	                ('Ajay Kedar','Ask123','ajayk5@birlasoft.com',getdate(),'System',null,null),
                    ('Ankit Gupta','1234','ankitg10@birlasoft.com',getdate(),'System',null,null);
              END  ";


            query = query + @" IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES 
              WHERE TABLE_NAME='RoleMaster') 

              BEGIN
               CREATE TABLE RoleMaster (
               RoleId int PRIMARY KEY IDENTITY (1, 1),
               RoleDescription nvarchar(25),
               CreatedOn DateTime NOT NULL,
               CreatedBy nvarchar(50) not null,
               ModifiedOn DateTime  NULL,
               ModifiedBy nvarchar(50) null
               ); 
               INSERT INTO RoleMaster(RoleDescription,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy )
               VALUES('Administrator',getdate(),'System',null,null),
               	('HO Administrator',getdate(),'System',null,null),
               	('Sys Administrator',getdate(),'System',null,null),
               	('Reviewer',getdate(),'System',null,null),
               	('Developer',getdate(),'System',null,null),
               	('Approver',getdate(),'System',null,null);
              END  ";
            query = query + @" IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES 
                  WHERE TABLE_NAME='UserRoles') 

              BEGIN
                CREATE TABLE UserRoles(
                 UserRoleId int PRIMARY KEY IDENTITY(1, 1),
                 UserId int FOREIGN KEY REFERENCES UserMaster(UserId),
                 RoleId int FOREIGN KEY REFERENCES RoleMaster(RoleId),
                 [Status] bit
                 );
                
                INSERT INTO UserRoles(UserId, RoleId, Status)
                 VALUES(2, 1, 1),
	                   (3, 1, 1),
                       (1, 2, 1);
              END  ";
              query = query + @"INSERT INTO[dbo].[WorkflowMaster] ( WorkflowName, LevelOfApprovals, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn)" +
                    " VALUES('" + _stWorkflowName + "'," + _inNumberOfSteps + ",'" + _createdBy + "',getDate(),'" + null + "','');" +
                    " Declare @id" + " int;" +
                    "Set @id" +  " = (SELECT SCOPE_IDENTITY()); ";

            //for (int i = _inNumberOfSteps; i >= 1; i--)
            //{
            //    string level = (Convert.ToInt32(i) - 1).ToString();
            //    if (level == 0.ToString())
            //        level = "''";
            //    else
            //        level = "'Level-" + (Convert.ToInt32(i) - 1).ToString() + "'";
            //    query = query + "INSERT INTO [dbo].[WorkflowStepsMaster] ( WorkflowId, StepTitle, ApprovalLevel, Description, AutoApprove, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) " +
            //         "VALUES( @id" + ",'" + _stWorkflowName + " Level-" + i + "'" + "," + level + "," + i + "," + (_status ? "1" : "0") + ",'" +  _createdBy+ "',GETDATE(),'" + null + "','');";
            //}
            
            foreach(var objlist in gridViewList)
            {
                query = query + "INSERT INTO [dbo].[WorkflowStepsMaster] ( WorkflowId, ApprovalLevel, Description, AutoApprove, WaitTime, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) " +
                      "VALUES( @id" + "," + "'" + objlist.Levels + "'" + ",'" + objlist.Desc + "'" + ",'" + objlist.Autoapprove + "'" + ",'" + objlist.Waittime + "'" + ",'" +  _createdBy+ "',GETDATE(),'" + null + "','');";
            }
            query = query.Remove(query.Length - 1, 1) + ";";

            SqlCommand sqlCommand = new SqlCommand(query, connection);
            bool success = Convert.ToBoolean(sqlCommand.ExecuteNonQuery());
            if (success)
            {
                MessageBox.Show("Records saved successfully!");

            }
            else
            {
                MessageBox.Show("Error while inserting records!");
            }
            connection.Close();

        }
    }
}
