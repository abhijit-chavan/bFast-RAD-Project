
namespace KPIT_K_Foundation
{
  internal enum ProjectFileType
  {
    WebApp,
    BusinessAndDataAPI,
    WebAPI,
  }
}
