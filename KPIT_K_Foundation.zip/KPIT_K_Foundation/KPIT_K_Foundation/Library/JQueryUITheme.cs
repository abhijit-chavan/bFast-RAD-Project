
namespace KPIT_K_Foundation
{
  internal enum JQueryUITheme
  {
    BlackTie,
    Blitzer,
    Cupertino,
    DarkHive,
    DotLuv,
    Eggplant,
    ExciteBike,
    HotSneaks,
    Humanity,
    LeFrog,
    MintChoc,
    Overcast,
    PepperGrinder,
    Redmond,
    Smoothness,
    SouthStreet,
    Start,
    Sunny,
    SwankyPurse,
    Trontastic,
    UIDarkness,
    UILightness,
    Vader,
  }
}
