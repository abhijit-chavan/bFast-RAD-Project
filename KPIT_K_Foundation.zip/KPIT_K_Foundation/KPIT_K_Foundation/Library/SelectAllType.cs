
namespace KPIT_K_Foundation
{
  internal enum SelectAllType
  {
    SelectShared,
    SelectAllDynamicWhere,
  }
}
