
namespace KPIT_K_Foundation
{
  internal enum CodeToGenerateType
  {
    DataLayerBase,
    DataLayer,
    BusinessObjectBase,
    BusinessObject,
    BusinessObjectCollection,
    CodeExample,
    StoredProcedure,
    DynamicSql,
    Helper,
    Models,
    ModelsBase,
    DomainHelper,
  }
}
