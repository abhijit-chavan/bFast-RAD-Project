
namespace KPIT_K_Foundation
{
  internal class ViewNames
  {
    internal string ListCrudRedirect { get; set; }

    internal string ListCrud { get; set; }

    internal string ListReadOnly { get; set; }

    internal string UpdateRecord { get; set; }

    internal string ListTotalsGroupedBy { get; set; }

    internal string ListTotals { get; set; }

    internal string ListGroupedBy { get; set; }

    internal string ListSearch { get; set; }

    internal string ListScrollLoad { get; set; }

    internal string ListInline { get; set; }

    internal string ListForeach { get; set; }

    internal string ListMasterDetailGrid { get; set; }

    internal string ListMasterDetailSubGrid { get; set; }

    internal string ListByRelatedField { get; set; }

    internal string AddRecord { get; set; }

    internal string RecordDetails { get; set; }

    internal string Unbound { get; set; }
  }
}
