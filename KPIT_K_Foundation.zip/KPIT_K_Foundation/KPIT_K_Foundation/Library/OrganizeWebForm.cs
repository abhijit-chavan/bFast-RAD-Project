
namespace KPIT_K_Foundation
{
  internal class OrganizeWebForm
  {
    internal string FolderForCheckedWebFormGridView { get; set; }

    internal string FolderForCheckedWebFormGridViewAddEdit { get; set; }

    internal string FolderForCheckedWebFormGridViewReadOnly { get; set; }

    internal string FolderForCheckedWebFormGridViewMoreInfo { get; set; }

    internal string FolderForCheckedWebFormGridViewTotals { get; set; }

    internal string FolderForCheckedWebFormGridViewGrouping { get; set; }

    internal string FolderForCheckedWebFormGridViewFilterBy { get; set; }

    internal string FolderForCheckedWebFormAddEdit { get; set; }

    internal string FolderForCheckedWebFormRecordDetails { get; set; }

    internal string FolderForCheckedWebFormUnbound { get; set; }

    internal string FolderForCheckedWebFormGridViewInline { get; set; }

    internal string FolderForCheckedWebFormGridViewSearch { get; set; }

    internal string PrefixForCheckedWebFormGridView { get; set; }

    internal string PrefixForCheckedWebFormGridViewAddEdit { get; set; }

    internal string PrefixForCheckedWebFormGridViewReadOnly { get; set; }

    internal string PrefixForCheckedWebFormGridViewMoreInfo { get; set; }

    internal string PrefixForCheckedWebFormGridViewTotals { get; set; }

    internal string PrefixForCheckedWebFormGridViewGrouping { get; set; }

    internal string PrefixForCheckedWebFormGridViewFilterBy { get; set; }

    internal string PrefixForCheckedWebFormAddEdit { get; set; }

    internal string PrefixForCheckedWebFormRecordDetails { get; set; }

    internal string PrefixForCheckedWebFormUnbound { get; set; }

    internal string PrefixForCheckedWebFormGridViewInline { get; set; }

    internal string PrefixForCheckedWebFormGridViewSearch { get; set; }
  }
}
