
namespace KPIT_K_Foundation
{
    internal enum MVCGridViewPart
    {
        Code,
        JavaScript,
        JavaScriptVariablesAndScript,
        JavaScriptInsideDollarFunctionHeader,
        ColNames,
        AdditionalColumns,
        AdditionalProperties,
        BodyBeforeGrid,
        BodyAfterGrid,
    }
}
