using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("KPIT K Foundation")]
[assembly: AssemblyDescription("ASP.NET Core 2.0 MVC Code Generator")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("KPIT ")]
[assembly: AssemblyProduct("Foundation")]
[assembly: AssemblyCopyright("Copyright © 2018")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("eda5fef5-b964-49db-8883-53bb2f3c3ea6")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: AssemblyVersion("2.0.0.0")]
